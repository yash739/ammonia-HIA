# Stutzki & Winnewisser (1985) NH3 escape-probability reproduction

A standalone Python reimplementation of the radiative-transfer model in
Stutzki & Winnewisser (1985, A&A 144, 13) — the escape-probability treatment
of hyperfine-selective radiative trapping in the NH3 (1,1) inversion
transition, used to explain "anomalous" hyperfine satellite intensities in
dense clumps. This package reproduces their Figs. 4-6, then investigates an
unexpected finding: a substantial part of the model's parameter space
predicts **population inversion (masing)** in one hyperfine satellite rather
than a bounded intensity ratio.

**What we want from you, two things:**

1. **Raw values for Stutzki's own contours.** Everything in `results/`
   is *our* model's output — we don't have a digitized, numeric version of
   what his Figs. 4-6 actually show, only the printed contour plots in
   `references/stutzki_1985.pdf`. To make our own direct, quantitative
   comparison plots (not just eyeballing two images side by side) we need
   actual (T_k, n_H2, N_NH3, ratio) values read off his contours, or his
   underlying model output if you have access to it some other way. If you
   have a way to get real numbers out of those printed figures — even a
   coarse digitization of a few contour lines per panel — that's the
   single most useful thing you could send back.
2. **An independent read on the masing result.** A substantial part of
   the model's parameter space predicts **population inversion (masing)**
   in one hyperfine satellite rather than a bounded intensity ratio. We
   want your opinion on whether that's (a) a real, defensible consequence
   of the physics as implemented, (b) an artifact of *this*
   implementation specifically, or (c) something in between we haven't
   correctly characterized. Sections 4 and 5 below lay out everything
   already checked, with results, so you don't have to re-derive the
   setup from scratch — but the conclusion is deliberately left open. If
   you find a bug, or a reason the masing conclusion doesn't hold up, that
   is the useful outcome here, not an unwelcome one.

Edits to any of this — the code, the README, the conclusions — are welcome
and expected; this isn't a finished result being handed off for approval,
it's a working analysis that could use a second, independent pass.

Origin: built across one extended session implementing the plan in
`references/stutzki_model_1985.md`, then chasing down the masing result
through several rounds of self-directed bug-hunting, a rate-dataset
substitution experiment, and a cross-check against an independent 3D
radiative-transfer calculation (Magritte). No claims below are final —
several are explicitly flagged as open.

---

## 1. Directory structure

```
README.md                    -- this file
code/
  stutzki85/                 -- the actual model + all analysis scripts
    nh3_escape_model.py      -- core: LAMDA parsing, hyperfine grouping,
                                 NLTE statistical-equilibrium solver,
                                 emergent-brightness diagnostics
    grid.py                  -- Phase 5: builds the (T_k, n_H2, N_NH3/dv)
                                 grid underlying Figs 4-6
    make_figures.py          -- reproduces Figs 4, 5, 6 (physically-honest
                                 version: NaN where a group masers)
    rate_swap_test.py        -- swaps in Stutzki & Winnewisser's OWN
                                 collision rates for the (1,1)-(2,1)
                                 pathway + Table 2's quasi-elastic rates,
                                 in place of the modern Loreau et al. (2023)
                                 default -- tests whether the masing result
                                 is rate-dataset-dependent
    rate_swap_full.py        -- extends the above to the FULL (1,1)
                                 rotational network Table 1 covers
    reproduce_raw_fig4a.py,
    reproduce_raw_fig4_full.py
                              -- reproduce Fig 4 using the LITERAL formula
                                 (no sign-of-tau check) instead of the
                                 physically-guarded default -- see Sect 5
    fit_observations.py      -- chi^2-fits the model directly against
                                 Stutzki & Winnewisser's own digitized
                                 observations (Table 2, 1984), attempting
                                 to reproduce their published fit
                                 parameters and the high-/low-density
                                 branch degeneracy (Tables 1a/1b, 1985)
    compare_magritte.py,
    compare_magritte_heatmap.py
                              -- cross-check against an independent 3D
                                 non-LTE radiative transfer run (Magritte)
  w33/                        -- dependencies fit_observations.py needs:
    stutzki_tables_full.py    parses the full digitized 1984+1985 tables
    scoring.py                 the chi^2 metric used for fitting
    observed_data/
      stutzki_1984_1985_full.csv  -- the digitized observational tables
                                      (see Sect 6)
  p-nh3@loreau.dat.txt        -- LAMDA-format molecular data file (energy
                                 levels, Einstein A, and Loreau et al. 2023
                                 NH3-H2 collision rates) that
                                 nh3_escape_model.py loads at runtime
results/                      -- every CSV/PNG these scripts have already
                                 produced (see Sect 3 for what's what)
magritte_comparison_data/
  NLTE_nh3_1e-6_parallel_12rays_v2.csv
                              -- the Magritte 3D RT run compare_magritte.py
                                 reads (see Sect 5.3 for an important
                                 caveat about this file)
references/                   -- the actual papers, so you can compare
                                 directly against the source
  stutzki_1985.pdf             Stutzki & Winnewisser 1985, A&A 144, 13 --
                                THE model paper. Figs. 4-6 are what this
                                package reproduces.
  Stutzki1984.pdf               Stutzki, Jackson, Olberg, Barrett &
                                Winnewisser 1984, A&A 139, 258 -- the
                                observational survey (Table 2 digitized
                                here is from this paper)
  Stutzki1985a.pdf               Stutzki & Winnewisser 1985, A&A 144, 1 --
                                companion paper with the IOS hyperfine
                                relative-factor tables (their Table 1)
  green1980.pdf                  Green 1980, J. Chem. Phys. 73, 2740 --
                                absolute NH3-He rotational collision rates
                                (their Table III), combined with the above
                                to get Stutzki's own absolute hyperfine
                                rates
  Loreau_Paper.pdf                Loreau et al. 2023, MNRAS 526, 3213 --
                                the modern NH3-H2 collision rates used as
                                the default dataset in this package
  stutzki_model_1985.md          the original implementation plan this
                                package follows (Phases 1-6)
```

---

## 2. Setup

Python 3.10+, with `numpy`, `scipy`, `pandas`, `matplotlib`. No compiled
dependencies, no Magritte installation needed for anything in `code/
stutzki85/` (Magritte was used once, previously, to generate the comparison
dataset in `magritte_comparison_data/`, which is included as a static CSV —
you don't need to re-run it).

```bash
cd code/stutzki85
python3 -c "import nh3_escape_model as m; model = m.NH3Model(); m.assert_expected_grouping(model); print('OK')"
```

All scripts use paths relative to their own location (via
`os.path.dirname(os.path.abspath(__file__))`), so the package runs correctly
regardless of where you unzip it — just keep the internal directory
structure intact (`code/stutzki85/`, `code/w33/`, `code/p-nh3@loreau.dat.txt`,
`results/`, `magritte_comparison_data/` all need to stay siblings/children in
this same layout).

---

## 3. What's already in `results/`

Everything below was generated by the scripts in `code/stutzki85/` and is
included so you can look at the outputs without re-running anything, or
diff your own re-run against these.

| File | Script | What it is |
|---|---|---|
| `stutzki85_fig4.png` / `.csv` | `grid.py` + `make_figures.py` | **The main deliverable.** Reproduction of Fig. 4a-c across the paper's 4-temperature grid, using default (Loreau) rates, with the physically-honest treatment: any hyperfine group with negative optical depth (population-inverted) is reported as NaN, visible as a blank patch, rather than a fabricated number. |
| `stutzki85_fig5.png`, `stutzki85_fig6.png` / `stutzki85_fig56_curves.csv` | same | Reproduction of Figs. 5-6 (outer/inner satellite ratio vs. main-line optical depth), same NaN convention. |
| `raw_fig4_loreau_only.png` / `.csv` | `grid.py` (`guard_masers=False`) | Fig. 4 with the *literal* formula — no sign-of-tau check — using Loreau's rates. This is what a 1985-style implementation with no masing awareness would have produced. |
| `raw_fig4_hybrid_full.png` / `.csv` | `reproduce_raw_fig4_full.py` + `rate_swap_test.py` | Same literal-formula reproduction, but with Stutzki's own rate for the (1,1)-(2,1) pathway substituted in (see Sect. 5.2). |
| `raw_fig4_full_hybrid.png` / `.csv` | `reproduce_raw_fig4_full.py` + `rate_swap_full.py` | Same, but with the *entire* (1,1) rotational network from Stutzki's own tables substituted in — the most complete rate-swap tested. |
| `raw_fig4a_hybrid.png` / `.csv` | `reproduce_raw_fig4a.py` | A smaller 2-panel version of the above (T=30, 36K only, R(0->1) and R(1->0) only) used earlier in the investigation — superseded by `raw_fig4_hybrid_full.png` but kept for reference. |
| `compare_magritte_T36.png` / `compare_escape_grid_T36.csv` | `compare_magritte.py` | Escape-probability model vs. the (label-corrected) Magritte 3D RT run, as line plots of ratio vs. optical depth. |
| `compare_diff_heatmap_T36.png` / `compare_paired_T36.csv` | `compare_magritte_heatmap.py` | The same comparison as a paired difference map (escape model minus Magritte) in the (n, N) plane and vs. optical depth — this is the more informative of the two Magritte comparisons; see Sect. 5.3. |
| `fit_observations.csv` | `fit_observations.py` | Direct chi^2 fits of the model against Stutzki's own digitized Table 2 observations (1984), for the 23 positions that have a matching published fit in his Table 1a (1985) — an attempt to reproduce his derived (T_k, n_H2, N_NH3) and the high-/low-density branch structure. See Sect. 6. |

---

## 4. How to reproduce/extend any of this

```bash
cd code/stutzki85

# Rebuild Figs 4-6 from scratch (~90s, no GPU/cluster needed)
python3 grid.py --out-dir ../../results
python3 make_figures.py

# The literal-formula (unguarded) version with default rates
python3 -c "
import nh3_escape_model as m, grid
model = m.NH3Model()
df = grid.compute_fig4_grid(model, solver_kwargs={'guard_masers': False})
df.to_csv('../../results/raw_fig4_loreau_only.csv', index=False)
"

# Rate-swap experiments (Stutzki's own rates instead of Loreau's)
python3 reproduce_raw_fig4_full.py     # full (1,1) rotational network swap

# Fit against his own observations
python3 fit_observations.py

# Compare against the Magritte 3D RT run
python3 compare_magritte.py
python3 compare_magritte_heatmap.py
```

Each grid point is a single 36-level statistical-equilibrium solve
(`scipy.optimize.root` on a `hybr`-method nonlinear system) — no meshing,
no ray tracing, no imaging. The full 4-temperature x 71 x 29 grid behind
Fig. 4 (~8200 points) runs in under two minutes on a laptop, which is the
whole point of using this escape-probability method instead of a full 3D
code for this parameter study.

---

## 5. The masing investigation — what's been checked, and what's still open

### 5.1 What "masing" means here, concretely

For a subset of the (T_k, n_H2, N_NH3/Delta v) grid — concentrated at high
column density, and worse at higher T_k — the model's converged
steady-state solution has **x_u/g_u > x_l/g_l** for the two levels behind
one hyperfine satellite (mostly the (1,1) F1=0->1 transition): the upper
level is genuinely overpopulated relative to its statistical weight, i.e.
population inversion, not just a large-but-normal excitation temperature.
The paper's own emergent-brightness formula (their Eq. 10, an escape
factor e(2*tau) built assuming tau >= 0) has no defined, physically
meaningful output once tau goes negative. `nh3_escape_model.py`'s default
behaviour is to report `NaN` for that hyperfine ratio rather than
extrapolate the formula past where its own derivation assumed — that's
the `guard_masers=True` default; `guard_masers=False` reproduces the raw,
unguarded number instead (see 5.4).

### 5.2 Checks that rule OUT it being a straightforward implementation bug

- **LTE limit**: at very high n_H2 (collision-dominated), the model
  recovers the pure-LTE hyperfine ratios exactly (matches the analytic
  Eq. 11 reference curve to 4 decimal places). Basic sanity check, passes.
- **Absolute brightness scale**: at very high optical depth the emergent
  T_B saturates at T_k - T_cmb to within 0.15% of the analytic
  Rayleigh-Jeans limit. The absolute calibration isn't the problem.
- **A real bug WAS found and fixed** during this investigation: the mean
  radiation field J_t could go negative for a masering group, which fed
  negative "rate coefficients" into the statistical-equilibrium matrix
  (physically nonsensical — a rate coefficient can never be negative).
  This is fixed in the current `nh3_escape_model.py` (see the
  `solve_populations`/`_build_residual_fn` docstrings for the exact
  mechanism). **Fixing it did not change the qualitative result**: the
  same levels still come out population-inverted afterward. This was
  checked directly (re-solving with the fix, confirming
  x_u/g_u > x_l/g_l persists) and via a level-by-level gain/loss
  accounting (the radiative pumping rate into the affected level alone
  exceeds its entire loss budget — radiative + all collisional channels
  combined — by roughly a factor of 4, independent of the fixed bug).
- **Sign conventions, grouping logic, and the hyperfine-transition
  bookkeeping** were independently cross-checked against Stutzki &
  Winnewisser's own printed values where available (Loreau et al. 2023's
  Table 3 quotes several of Stutzki & Winnewisser 1985a's relative factors
  directly; our independent transcription from the scanned original
  matches to 2 significant figures, and every row satisfies the required
  Eq. 12a identity, sum of relative factors = 1.000, exactly).

None of this *proves* there's no remaining bug — it means the obvious,
checkable candidates have been ruled out. An independent read of
`nh3_escape_model.py`, especially `_build_residual_fn` (the physics core)
and `group_brightness_temperatures` (where tau's sign is handled), is
exactly the kind of check we'd want from a second pair of eyes.

### 5.3 The rate-dataset and Magritte comparisons — the two most substantive external checks

**Rate substitution** (`rate_swap_test.py`, `rate_swap_full.py`): the
default collision dataset is Loreau et al. (2023) (NH3-H2, modern
close-coupling calculation), not Stutzki & Winnewisser's own 1985 estimate
(NH3-He, cruder IOS approximation, scaled by a factor to stand in for
H2). Swapping in as much of Stutzki's own rate data as could be recovered
from Green (1980) Table III and Stutzki & Winnewisser (1985a) Table 1
**reduces but does not eliminate** the masing region — see
`raw_fig4_full_hybrid.png` vs `raw_fig4_loreau_only.png`. Both show the
same qualitative anomaly (same sign, same location in parameter space);
the rate choice changes how deep it goes, not whether it happens.

Separately: reproducing Fig. 4a *literally* (no sign check) with Stutzki's
own rate for the critical (1,1)-(2,1) pathway lands within a few percent
of the actual printed contour values in his own Fig. 4a at at least one
directly-checked point (predicted R(0->1)=2.03 against a point sitting
right on his own paper's plotted "2.0" contour) — suggesting his own 1985
calculation may have crossed into the same regime without him noticing,
since his formula (like ours before the guard was added) doesn't fail
visibly when tau goes negative, it just keeps producing plausible-looking
numbers. This is circumstantial, not confirmed — we don't have his actual
code or a not-published note where he'd have flagged it if he'd checked.

**Magritte comparison** (`compare_magritte.py`,
`compare_magritte_heatmap.py`): a completely independent 3D non-LTE
radiative transfer calculation (Magritte, ray-based, full geometry, no
escape-probability approximation) at T=36K was compared directly.
IMPORTANT CAVEAT: this Magritte dataset predates a hyperfine-satellite
labelling fix in the source pipeline (an outer-pair swap, R(0->1) and
R(1->0) were mislabelled; the inner pair was unaffected by the same bug —
see the docstring at the top of `compare_magritte.py` for the full,
independently-rederived proof of exactly which pair was swapped and why).
**The correction is applied in code before comparison** — treat the
corrected values as the best available reading of that Magritte run, not
as raw/untrusted. Findings:
  - Inner satellites showed what first looked like excellent 3-way
    agreement (Magritte, escape model, LTE) in a line-plot comparison —
    **but the difference-map view (`compare_diff_heatmap_T36.png`) shows
    this was misleading**: there's a real, systematic offset peaking
    around tau~1 (escape model 0.4-0.6 higher than Magritte there),
    sitting *inside* the tau range (0.1-2) the original paper claims its
    own center-of-sphere approximation should be good in. This is
    unexplained. It is the single most important open thread in this
    whole investigation.
  - Outer satellites: same sign/mechanism in both methods (real
    confirmation the anomaly isn't a pure escape-probability artifact),
    but density-dependent, non-uniform disagreement in magnitude — not a
    simple "escape model always more extreme" pattern.
  - Most of the R(0->1) comparison is not usable: Magritte's own N_NH3
    sweep there goes to ~100x higher column density than this package's
    Fig. 4 grid, deep into masing on the escape-probability side for
    nearly all of those points.

**This Magritte comparison is the most promising avenue for you to push
on independently** — both because the τ~1 inner-satellite offset is
unexplained, and because a from-scratch reviewer might reasonably weight
the escape-probability approximation's known limitations, or the Magritte
setup's own assumptions (geometry, linewidth treatment), differently than
this session did.

### 5.4 If you want to reproduce the raw/unguarded numbers yourself

```python
import nh3_escape_model as m
model = m.NH3Model()
Cmat = model.collision_matrix(36.0)
out = m.run_one(model, Cmat, T_k=36.0, n_H2=1e5, log_N_dv=15.0, guard_masers=False)
print(out['R_01'])  # the literal formula's output, not NaN
```

---

## 6. The digitized observational data and the fit-to-observations attempt

`code/w33/observed_data/stutzki_1984_1985_full.csv` is a full digitization
of every numbered table across both papers: Table 1-3 from the 1984
observational survey (source list, the 51 positions with hyperfine
anomalies and their ratios/uncertainties, and the 12 non-anomalous control
sources), and Tables 1a/1b/2a/2b/3 from the 1985 model paper (his own
fitted parameters for both the adopted high-density and rejected
low-density branch, the derived clump properties, and the (2,1)
observation set). `code/w33/stutzki_tables_full.py` parses it; its
module docstring documents and resolves a real column-ordering ambiguity
in the source table (statistically checked against the known anomaly
sense, 78% vs 71% — not a coin flip, but also not unanimous, so treat
individual low-S/N rows in that table with appropriate caution).

`fit_observations.py` fits `nh3_escape_model` directly (on the fly, not
via a precomputed grid — each fit takes a few seconds) against the
23 positions where Table 2's observed ratios have a matching Table 1a
entry to compare against, using two starting points (seeded toward a
high-density and low-density solution respectively) per position to try
to recover both branches of Stutzki's own degenerate solution.

**Result, honestly**: partial. The qualitative two-branch structure
reproduces (distinct basins found for most sources), and — independently
of what the optimizer is told to fit — 7 of the 10 comparable low-density
branches come out with an unphysical filling factor (eta_f > 1), matching
his own stated reason for rejecting that branch. Recovered density
(log n_H2) lands within 0.5 dex of his published value for about half the
sources. Recovered temperature shows a **systematic low bias** relative
to his fits in most cases (often 5-16 K low) — not scatter, a one-sided
trend, most likely (but not confirmed) tied to the same rate-dataset
difference discussed in Sect. 5.3. Three of the 23 fits hit the
optimizer's parameter bounds (clear optimizer failures, not real minima —
these need a more robust global search, e.g. `scipy.optimize.
differential_evolution`, or wider bounds, before trusting them). Full
per-source results, both branches, in `results/fit_observations.csv`.

---

## 7. Known limitations / things not to over-read

- The escape-probability closure uses a single representative escape
  probability evaluated at the cloud's center for the whole sphere — the
  paper itself states this approximation is only expected to be good for
  tau in roughly [0.1, 2]. A lot of the masing region is well outside
  that range, though (per Sect. 5.3) the τ~1 inner-satellite Magritte
  discrepancy sits *inside* it, which is why that's flagged as the open
  question rather than a settled explanation.
- Collision rates: default is Loreau et al. (2023) NH3-H2 (modern,
  accurate, full close-coupling). Where Stutzki's own 1985 NH3-He/IOS
  rates could be recovered from the source papers (Sect. 5.3), they've
  been substituted in for comparison, but full coverage of his rate table
  was not achievable — some pathways (anything not touching the (1,1)
  level directly) still fall back to Loreau's rates in the "hybrid"
  reproductions.
- Delta v_clump is fixed at 0.3 km/s throughout, matching the paper's own
  fixed clump linewidth assumption — not treated as a free parameter
  anywhere in this package.
- `fit_observations.py`'s chi^2 convention (mean of normalized-residual
  squares) is not necessarily the same normalization Stutzki used for the
  chi^2 values printed in his own Table 1a/1b — don't compare those
  numbers directly, compare the fitted *parameters*.

---

## 8. Contact / provenance

Built by Claude (Anthropic) working with Yash Rai (yashrai739@gmail.com)
across an extended session on the `magritte_rebuilt` repository. This
README and the code comments throughout `code/stutzki85/` aim to carry
enough context that a from-scratch reader doesn't need the original
conversation to follow the reasoning — every non-obvious choice is
explained in a docstring near where it's made. If something looks
unexplained, that's a gap worth flagging back, not a sign it was
deliberately hidden.
